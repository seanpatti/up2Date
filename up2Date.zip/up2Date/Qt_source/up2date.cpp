/*   This file is part of the up2Date project. <Copyrignt © 2016 Sean Patti Projects>
 *
 *   periodic_table is free software: you can redistribute it
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at our option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "up2date.h"
#include "ui_up2date.h"
#include "dbWorker.h"
#include <QDesktopServices>
#include <QtNetwork>
#include <QMessageBox>
#include <QScrollBar>
#include <QThread>

// Locals to hold the information from the thread.
QString dwnPath;
QString u;
QString thisVer;

// Sets the thread done flag.
QString bk;
// Sets the db ID so we know we are updating the right program.
QString id;
// Sets the version from the db table.
QString vr;
// Sets the discription from the db table.
QString dbDis;
// Sets the update URL path. Please don't forget the http:// this is how we know what protocal to use.
QString dbU;

// Set the default download location.
const QString downloadsFolder = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);



// ***** Change Me *****
// Set the application name that was used in the database. This way you can run up2Date with multiple projects.
const QString dbappName = "<Your_project_id>";

// ***** Change Me *****
// Set the full name of the program.
const QString longName = "<Your_project_long_name>";



up2Date::up2Date(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::up2Date)
{
    // Remove the ? from the dialog form
    setWindowFlags(windowFlags() &~Qt::WindowContextHelpButtonHint);

    ui->setupUi(this);
    this->setWindowTitle("up2Date");
    ui->lblServer->setText("Server Status: Checking for update...");

    connect(ui->buttonUpdate, SIGNAL(clicked()), this, SLOT(downloadFile()));
    connect(ui->buttonCancel, SIGNAL(clicked()), this, SLOT(close()));

    // The thread and the worker are created in the constructor so it is always safe to delete them.
    thread = new QThread();
    worker = new dbWorker();

    // Worker thread connects.
    worker->moveToThread(thread);
    connect(worker, SIGNAL(workRequested()), thread, SLOT(start()));
    connect(thread, SIGNAL(started()), worker, SLOT(doWork()));
    connect(worker, SIGNAL(finished()), thread, SLOT(quit()), Qt::DirectConnection);

    // Gets return from thread.
    connect(worker, SIGNAL(threadDone(QString)), this, SLOT(isDone(QString)));
    connect(worker, SIGNAL(dbRptVer(QString)), this, SLOT(dbVer(QString)));
    connect(worker, SIGNAL(dbCkId(QString)), this, SLOT(getdbCkId(QString)));
    connect(worker, SIGNAL(dbDis(QString)), this, SLOT(getDis(QString)));
    connect(worker, SIGNAL(pURL(QString)), this, SLOT(gURL(QString)));

    // To avoid having two threads running simultaneously, the previous thread is aborted.
    worker->abort();
    // If the thread is not running, this will immediately return.
    thread->wait();

    worker->requestWork();

    // Set a timer so we timeout after a reasonable time.
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(dbTimerTick()));

    timer->start(500);
}

up2Date::~up2Date()
{
    // Remove the thead and close out the application.
    worker->abort();
    thread->wait();
    delete thread;
    delete worker;
    delete ui;
}

void up2Date::startRequest(QUrl url)
{
    // Use the link we got back from the database. Make sure it has the http:// in it.
    reply = qnam.get(QNetworkRequest(url));

    connect(reply, SIGNAL(finished()), this, SLOT(httpFinished()));
    connect(reply, SIGNAL(readyRead()), this, SLOT(httpReadyRead()));
    connect(reply, SIGNAL(downloadProgress(qint64,qint64)), this, SLOT(updateDataReadProgress(qint64,qint64)));
}

// Timeer to check our query. Also times out if we cannot coneect to the database.
void up2Date::dbTimerTick()
{
    if(bk == "Done")
    {
        if(dbappName == id && thisVer == vr)
        {
            ui->txtDetails->setPlainText("Version:" + thisVer + " is the latest version of the " + longName + ".");
            ui->lblServer->setText("Server Status: No update found.");
        }
        else
        {
            ui->txtDetails->setPlainText("Version:" + vr + " is available for download.\n");
            ui->txtDetails->appendPlainText(dbDis);
            ui->txtDetails->moveCursor(QTextCursor::Start);
            ui->buttonUpdate->setEnabled(true);
            ui->lblServer->setText("Server Status: Update found.");
            ui->buttonUpdate->setFocus();
        }
        if(bk == "Done" && vr == "")
        {
            ui->lblServer->setText("Server Status: Unavailable");
            ui->txtDetails->setPlainText("The update server did not respond.");
            this->setWindowTitle("up2Date");
            for(int i = 0; i < 50000; i++)
            {
                ui->lblServer->setText("Server Status: Update Server Unavailable");
                ui->txtDetails->setPlainText("The update server did not respond.");
                ui->buttonUpdate->setEnabled(false);
                timer->stop();
            }
        }
        timer->stop();
    }
}

void up2Date::receiveV(QString v)
{
    // Set the up2Date "Update" button to disabled.
    ui->buttonUpdate->setEnabled(false);
    // Get the current version running.
    thisVer = v;
}

// Downloads our update to local downloads folder and checks for errors.
void up2Date::downloadFile()
{
    url = dbU;

    QFileInfo fileInfo(url.path());
    QString fileName = downloadsFolder + "/" + fileInfo.fileName();
    dwnPath = fileName;


    if(QFile::exists(fileName))
    {
        if(QMessageBox::question(this, tr("up2Date"), tr("There already exists a file called %1 in the current directory. Overwrite?").arg(fileName), QMessageBox::Yes|QMessageBox::No, QMessageBox::No) == QMessageBox::No)
            this->close();

        QFile::remove(fileName);
    }

    file = new QFile(fileName);
    if(!file->open(QIODevice::WriteOnly))
    {
        QMessageBox::information(this, tr("up2Date"), tr("Unable to save the file %1: %2.").arg(fileName).arg(file->errorString()));
        delete file;
        file = 0;
        return;
    }

    httpRequestAborted = false;
    startRequest(url);
}

void up2Date::cancelDownload()
{
    httpRequestAborted = true;
    reply->abort();
}

// Error handling for the file download.
void up2Date::httpFinished()
{
    if(httpRequestAborted)
    {
        if(file)
        {
            file->close();
            file->remove();
            delete file;
            file = 0;
        }
        reply->deleteLater();
        return;
    }

    file->flush();
    file->close();

    QVariant redirectionTarget = reply->attribute(QNetworkRequest::RedirectionTargetAttribute);
    if (reply->error())
    {
        file->remove();
        QMessageBox::information(this, tr("up2Date"), tr("Download failed: %1.").arg(reply->errorString()));
        ui->buttonUpdate->setEnabled(true);
    }
    else if(!redirectionTarget.isNull())
    {
        QUrl newUrl = url.resolved(redirectionTarget.toUrl());
        if (QMessageBox::question(this, tr("up2Date"), tr("Redirect to %1 ?").arg(newUrl.toString()), QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
        {
            url = newUrl;
            reply->deleteLater();
            file->open(QIODevice::WriteOnly);
            file->resize(0);
            startRequest(url);
            return;
        }
    }

    reply->deleteLater();
    reply = 0;
    delete file;
    file = 0;
}

// We have data. Write it out to disk if we can.
void up2Date::httpReadyRead()
{
    if(file)
       file->write(reply->readAll());
}

// Triggers and updates the progressbar.
void up2Date::updateDataReadProgress(qint64 bytesRead, qint64 totalBytes)
{
    if(httpRequestAborted)
        return;

    ui->downloadProgress->setMaximum(totalBytes);
    ui->downloadProgress->setValue(bytesRead);
    ui->lblServer->setText("Server Status: Downloading...");
    ui->buttonUpdate->setEnabled(false);

    if(bytesRead == totalBytes)
        ui->lblServer->setText("Server Status: Download Complete!");

    if(bytesRead == totalBytes)
        ui->txtDetails->setPlainText("Your update has been downloaded to " + dwnPath + "\n\n" + "Please uninstall this version before running the upgrade.");

    if(bytesRead == totalBytes)
        ui->buttonCancel->setText("Close");
}

void up2Date::isDone(QString y)
{
    bk = y;
}

void up2Date::dbVer(QString dbv)
{
    vr = dbv;
}

void up2Date::getdbCkId(QString did)
{
    id = did;
}

void up2Date::getDis(QString s)
{
    dbDis = s;
}

void up2Date::gURL(QString u)
{
    dbU = u;
}

void up2Date::on_buttonUpdate_clicked()
{
    // Called elsewhere.
}

void up2Date::on_buttonCancel_clicked()
{
    this->close();
}
