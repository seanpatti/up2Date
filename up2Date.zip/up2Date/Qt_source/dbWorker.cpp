/*   This file is part of the up2Date project. <Copyrignt © 2016 Sean Patti Projects>
 *
 *   periodic_table is free software: you can redistribute it
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at our option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "dbWorker.h"
#include "up2date.h"
#include <QThread>
#include <QSql>
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

dbWorker::dbWorker(QObject *parent) : QObject(parent)
{
    _working =false;
    _abort = false;
}

void dbWorker::requestWork()
{
    mutex.lock();
    _working = true;
    _abort = false;
    mutex.unlock();

    emit workRequested();
}

void dbWorker::abort()
{
    // Unlocks our mutex and clears the database connection string.
    mutex.lock();
    if (_working)
    {
        _abort = true;
    }
    mutex.unlock();
    QSqlDatabase::removeDatabase("update_conn");
}

void dbWorker::doWork()
{
    QString checkID;
    QString chkVer;
    QString diSrpt;
    QString pathURL;

    // Checks if the process should be aborted
    mutex.lock();
    bool abort = _abort;
    mutex.unlock();

    if (abort)
    {
        return;
    }
    // Setup the database connection.
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL", "update_conn");

    // ***** Change Me *****
    // The server name where the MySql database is hosted.
    db.setHostName("<Your_MYSQL_Host>");

    // ***** Change Me *****
    // Name of the update database
    db.setDatabaseName("<Your_Database_Name>");

    // ***** Change Me *****
    // The user who has acess to the update database.
    db.setUserName("<Your_Database_User_Name>");

    // ***** Change Me *****
    // Update database password.
    db.setPassword("<Your_Database_User_Password>");

    if(!db.open())
    {
        // Set the database name.
        db.setDatabaseName("update_conn");
    }
    else
    {
         db.close();
    }

        QSqlQuery qry(QSqlDatabase::database("update_conn"));

        if(qry.exec("SELECT check_version.id,check_version.poject_name,check_version.current,check_version.discription,check_version.url FROM currentversion.check_version check_version ORDER BY check_version.current ASC"))
        {
            while(qry.next())
            {
                // Gets the project ID.
                checkID = qry.value(1).toString();
                // Gets the current version.
                chkVer = (qry.value(2).toString());
                // Gets the current version description.
                diSrpt = (qry.value(3).toString());
                // Gets the current version download path.
                pathURL = (qry.value(4).toString());
            }
            db.close();
        }

    // Set _working to false, meaning the process can't be aborted anymore.
    mutex.lock();
    _working = false;
    mutex.unlock();

    db.close();

    // Thread finished signal is sent
    emit finished();
    QString d; // This is our thread done flag.
    d = "Done";

    emit dbCkId(checkID);
    emit dbRptVer(chkVer);
    emit dbDis(diSrpt);
    emit threadDone(d);
    emit pURL(pathURL);
}
