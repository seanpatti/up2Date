#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->btnTest->hasFocus();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnQuit_clicked()
{
    this->close();
}

void MainWindow::on_btnTest_clicked()
{
    u2d = new up2Date(this);
    u2d->setModal(true);
    u2d->show();

    // This is a sample.
    // This is where you will pass your projects version. See the documentation
    const QString v = "1.0.0.1";

    // Connector for the dialog to receive the program version.
    connect(this, SIGNAL(sendV(QString)), u2d, SLOT(receiveV(QString)));

    // Emitter.
    emit sendV(v);
}
