/*   This file is part of the up2Date project. <Copyrignt © 2016 Sean Patti Projects>
 *
 *   periodic_table is free software: you can redistribute it
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at our option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DBWORKER_H
#define DBWORKER_H

#include <QObject>
#include <QMutex>

class dbWorker : public QObject
{
    Q_OBJECT
public:
    explicit dbWorker(QObject *parent = 0);

    void requestWork();

    void abort();

private:

    bool _abort;

    bool _working;

    QMutex mutex;

signals:

    void workRequested();

    void finished();

    void threadDone(QString);

    void dbCkId(QString);

    void dbDis(QString);

    void pURL(QString);

    void dbRptVer(QString);


public slots:

    void doWork();

};

#endif // DBWORKER_H
