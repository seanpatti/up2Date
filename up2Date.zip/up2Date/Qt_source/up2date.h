/*   This file is part of the up2Date project. <Copyrignt © 2016 Sean Patti Projects>
 *
 *   periodic_table is free software: you can redistribute it
 *   it under the terms of the GNU Lesser General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at our option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef UP2DATE_H
#define UP2DATE_H

#include <QDialog>
#include <QThread>
#include <QNetworkAccessManager>
#include <QFile>
#include <QUrl>

#include "dbWorker.h"

namespace Ui {
class up2Date;
}

class up2Date : public QDialog
{
    Q_OBJECT

public:
    explicit up2Date(QWidget *parent = 0);
    ~up2Date();

    void startRequest(QUrl url);

    dbTimer();
    QTimer *timer;

private slots:
    // Slot to receive the program version string.
    void receiveV(QString v);

    void dbTimerTick();

    void on_buttonCancel_clicked();

    void on_buttonUpdate_clicked();

    // Start of download

    void downloadFile();

    void cancelDownload();

    void httpFinished();

    void httpReadyRead();

    void updateDataReadProgress(qint64 bytesRead, qint64 totalBytes);

    // End download

    void isDone(QString y);

    void getdbCkId(QString did);

    void getDis(QString s);

    void gURL(QString u);

    void dbVer(QString dbv);

signals:

    void sendURL(QString);

    void senduName(QString);

private:
    Ui::up2Date *ui;
    QUrl url;
    QNetworkAccessManager qnam;
    QNetworkReply *reply;
    QFile *file;
    int httpGetId;
    bool httpRequestAborted;

    QThread *thread;
    dbWorker *worker;

};

#endif // UP2DATE_H
