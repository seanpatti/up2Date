#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "up2date.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

signals:

    void sendV(QString);

private slots:


    void on_btnQuit_clicked();

    void on_btnTest_clicked();

private:
    Ui::MainWindow *ui;
    up2Date *u2d;
};

#endif // MAINWINDOW_H
